

#include <http.h>
#include <sys/time.h>

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <data_control.h>


#ifndef __cloud_H__
#define __cloud_H__


int send_test_request();

//int _request(http_session_h* session);

#endif /* __cloud_H__ */

