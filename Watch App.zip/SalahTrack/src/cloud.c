#include "cloud.h"
//#include <http.h>
//#include <stdbool.h>
#include<string.h>
//#include<json-c/json.h>
#include"dlog.h"

#include <curl/curl.h>
#include <net_connection.h>
//#include <json-c/json.h>


int  send_test_request(){
	CURL *curl;
	CURLcode curl_err;
	struct json_object *jobj;
	//char *str={\'x'\:x,'y':y,'z':z};

	/*jobj=json_object_new_object();
	json_object_object_add(jobj,"x",json_object_new_string(12));
	dlog_print(DLOG_INFO,"HttpRequest","json %s",jobj);*/

	//jobj = json_tokener_parse(str);
	const char* post_msg = "x=10.5& y=2& z=3";
	//string s="This is me";
	char *res;
	curl = curl_easy_init();
	//curl_easy_setopt(curl, CURLOPT_URL, "http://ptsv2.com/t/l9nm6-1646251833/post");
	curl_easy_setopt(curl, CURLOPT_URL, "https://tizenflask.herokuapp.com/getValues");
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_msg);


	//curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
	//res = curl_easy_recv(curl, buf, sizeof(buf), &nread);
	//curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE,&readBuffer);


	curl_err = curl_easy_perform(curl);
	int nread;
	char *buf;
	curl_easy_recv(curl, buf, sizeof(buf), &nread);

	if (curl_err != CURLE_OK){
		dlog_print(DLOG_INFO,"HttpRequest","Curl Failed:  %d", curl_err);
	}else{
		dlog_print(DLOG_INFO,"HttpRequest","Curl Success %c",buf);
	}
	curl_easy_cleanup(curl);
	return 0;
}
