#ifndef __salahtrack_H__
#define __salahtrack_H__

#include <app.h>
#include <Elementary.h>
#include <system_settings.h>
#include <efl_extension.h>
#include <dlog.h>

#ifdef  LOG_TAG
#undef  LOG_TAG
#endif
#define LOG_TAG "salahtrack"

#if !defined(PACKAGE)
#define PACKAGE "org.example.salahtrack"
#endif

#endif /* __salahtrack_H__ */
