/*
 * sensorcb.c
 *
 *  Created on: Sep 20, 2021
 *      Author: Hp



#include "salahtrack.h"
#include <sensor.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
#include <data_control.h>
#include <sqlite3.h>
#include <glib.h>
#include <http.h>
#include<dlog.h>
//#include"sqldb.h"

#define TAG "MYTAG"

typedef struct appdata {
	Evas_Object *win;
	Evas_Object *conform;
	Evas_Object *button;
	Evas_Object *naviframe;


	sensor_h accel_sensor;
	sensor_h gyro_sensor;
	sensor_h heart_sensor;
	sensor_listener_h accel_listener;
	sensor_listener_h gyro_listener;
	sensor_listener_h heart_listener;



	char * timer;
	float swing_data[64000][8];
	char time_data[64000][84];
	int accel_count;
	int gyro_count;
	int heart_count;
} appdata_s;

/*void my_print(char *format, ...)
{
    va_list a;
    va_start(a, format);
    dlog_vprint(DLOG_INFO, "USR_TAG", format, a);
    va_end(a);
}



static void _button_click_cb(void *data, Evas_Object *button, void *ev)
{
	appdata_s *ad = data;
	if (strcmp(elm_object_part_text_get(button, NULL), "START") == 0)
	{
		ad->accel_count=0;
		ad->gyro_count=0;
		ad->heart_count=0;
		sensor_listener_start(ad->accel_listener);
		sensor_listener_start(ad->gyro_listener);
		sensor_listener_start(ad->heart_listener);
		elm_object_text_set(button, "STOP");

		//File saving on stop issue catcher

	}
	else
	{
		sensor_listener_stop(ad->accel_listener);
		sensor_listener_stop(ad->gyro_listener);
		sensor_listener_stop(ad->heart_listener);
		elm_object_text_set(button, "START");

		FILE* fp=NULL;
		float temp;
		struct timeval curTime;
		gettimeofday(&curTime, NULL);

		char buffer [80];
		strftime(buffer, 80, "%Y_%m_%d_%H_%M_%S", localtime(&curTime.tv_sec));
		char currentTime[84] = "";
		sprintf(currentTime, "%s", buffer);
		char filename[100];
		strcpy(filename,currentTime);
						//strcpy(filename,".csv");
		strncat(filename, ".csv", 4);
		char path[100]="/opt/usr/home/owner/share/tmp/sdk_tools/";
		strncat(path,filename,23);
		fp = fopen(path,"w");
		//my_debug_print("%s",path);

		char data_string[256];

		//debugger

		for (int i = 0; i < (ad->accel_count); i++)
		{
			//strcpy(data_string,"\0" );
			sprintf(data_string, "%f, %f, %f,%f, %f, %f,%f, %s," , (ad->swing_data)[i][1], (ad->swing_data)[i][2], (ad->swing_data)[i][3], (ad->swing_data)[i][4] , (ad->swing_data)[i][5], (ad->swing_data)[i][6],(ad->swing_data)[i][7],ad->time_data[i]);

			fprintf(fp, "%s\n", data_string);
		}
		//strcpy(data_string,"\0" );
		fclose(fp);

	}
}
                  // ACCELEROMETER CALLBACK ////


static void
accelerometer_cb(sensor_h sensor, sensor_event_s *event, void *data)
{
	appdata_s *ad = data;

	struct timeval curTime;
	gettimeofday(&curTime, NULL);
	int milli = curTime.tv_usec / 1000;

	char buffer [80];
	strftime(buffer, 80, "%Y-%m-%d_%H:%M:%S", localtime(&curTime.tv_sec));
	char currentTime[84] = "";
	sprintf(currentTime, "%s:%03d", buffer, milli);
	printf("current time: %s \n", currentTime);
		//Hie
	for(int i = 0; i< sizeof(currentTime); i++)
	{
		ad->time_data[ad->accel_count][i] = currentTime[i];
	}


	//catch time debugger

	ad->swing_data[ad->accel_count][1] = event->values[0];
	ad->swing_data[ad->accel_count][2] = event->values[1];
	ad->swing_data[ad->accel_count][3] = event->values[2];
	ad->accel_count++;
}


   	   	   	   	   	   	  // GYROSCOPE CALLBACK //



static void
gyroscope_cb(sensor_h sensor, sensor_event_s *event, void *data)
{
	appdata_s *ad = data;
	ad->swing_data[ad->gyro_count][4] = event->values[0];
	ad->swing_data[ad->gyro_count][5] = event->values[1];
	ad->swing_data[ad->gyro_count][6] = event->values[2];
	ad->gyro_count++;


}



			// HEART BEAT CALL BACK

static void
heart_cb(sensor_h sensor, sensor_event_s *event, void *data)
{
	appdata_s *ad = data;
	ad->swing_data[ad->heart_count][7] = event->values[0];
	dlog_print(DLOG_INFO, "USR_TAG", "test dlog");
	ad->heart_count++;
}



static void sens_calling(void *data)
{
	appdata_s *ad=data;


	sensor_get_default_sensor(SENSOR_ACCELEROMETER, &(ad->accel_sensor));

		sensor_create_listener(ad->accel_sensor, &(ad->accel_listener));
		sensor_listener_set_event_cb(ad->accel_listener, 50, accelerometer_cb, ad);
		sensor_listener_set_option(ad->accel_listener, SENSOR_OPTION_ALWAYS_ON);

		sensor_get_default_sensor(SENSOR_GYROSCOPE, &(ad->gyro_sensor));
		sensor_create_listener(ad->gyro_sensor, &(ad->gyro_listener));
		sensor_listener_set_event_cb(ad->gyro_listener, 50, gyroscope_cb, ad);
		sensor_listener_set_option(ad->gyro_listener, SENSOR_OPTION_ALWAYS_ON);

		sensor_get_default_sensor(SENSOR_HRM, &(ad->heart_sensor));
		sensor_create_listener(ad->heart_sensor, &(ad->heart_listener));
		sensor_listener_set_event_cb(ad->heart_listener,50, heart_cb, ad);
		sensor_listener_set_option(ad->heart_listener, SENSOR_OPTION_ALWAYS_ON);


}


				// CREATE GUI ///


static void
win_delete_request_cb(void *data, Evas_Object *obj, void *event_info)
{
	ui_app_exit();
}

static void
win_back_cb(void *data, Evas_Object *obj, void *event_info)
{
	appdata_s *ad = data;
	elm_win_lower(ad->win);
}





static void
create_base_gui(appdata_s *ad)
{


	//Evas_Object *win=NULL;
	Evas_Object *label = elm_label_add(sin);

	elm_object_text_set(label, "Some long text for our label, that is not so long");
	elm_object_style_set(label, "slide_roll");
	elm_label_slide_duration_set(label, 3);
	elm_label_slide_mode_set(label, ELM_LABEL_SLIDE_MODE_ALWAYS);

	ad->win = elm_win_util_standard_add(PACKAGE, PACKAGE);
	elm_win_autodel_set(ad->win, EINA_TRUE);

	if (elm_win_wm_rotation_supported_get(ad->win)) {
		int rots[4] = { 0, 90, 180, 270 };
		elm_win_wm_rotation_available_rotations_set(ad->win, (const int *)(&rots), 4);
	}

	evas_object_smart_callback_add(ad->win, "delete,request", win_delete_request_cb, NULL);
	eext_object_event_callback_add(ad->win, EEXT_CALLBACK_BACK, win_back_cb, ad);

	ad->conform = elm_conformant_add(ad->win);
	elm_win_indicator_mode_set(ad->win, ELM_WIN_INDICATOR_SHOW);
	elm_win_indicator_opacity_set(ad->win, ELM_WIN_INDICATOR_OPAQUE);
	evas_object_size_hint_weight_set(ad->conform, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	elm_win_resize_object_add(ad->win, ad->conform);
	evas_object_show(ad->conform);

		//Naviframe
	ad->naviframe=elm_naviframe_add(ad->conform);
	elm_object_content_set(ad->conform,ad->naviframe);
	evas_object_show(ad->conform);

		//Box
	Evas_Object * box=elm_box_add(ad->naviframe);
	elm_box_horizontal_set(box,EINA_FALSE);
	evas_object_size_hint_weight_set(box,EVAS_HINT_EXPAND,EVAS_HINT_EXPAND);
	evas_object_size_hint_align_set(box,EVAS_HINT_FILL,EVAS_HINT_FILL);
	elm_naviframe_item_push(ad->naviframe,"",NULL,NULL,box,NULL);
	evas_object_show(box);



		//Button
	ad->button=elm_button_add(box);
	evas_object_size_hint_weight_set(ad->button,EVAS_HINT_EXPAND,EVAS_HINT_EXPAND);
	evas_object_size_hint_align_set(ad->button,EVAS_HINT_FILL,0.5);
	elm_object_text_set(ad->button,"START");

	elm_box_pack_end(box,ad->button);
	evas_object_show(ad->button);

		/* Show window after base gui is set up
	evas_object_show(ad->win);

	sens_calling(ad);

}*/



