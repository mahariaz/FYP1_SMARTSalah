#include "cloud.h"
//#include <http.h>
//#include <stdbool.h>
#include<string.h>
//#include<json-c/json.h>
#include"dlog.h"
#include <fcntl.h>

#include <curl/curl.h>
#include <net_connection.h>
#include <sys/stat.h>
//#include <json-c/json.h>


int  send_test_request(char* path){
	CURL *curl;
	CURLcode curl_err=0;
	struct stat file_info;

	curl_off_t speed_upload, total_time;
	//char *str={\'x'\:x,'y':y,'z':z};
	dlog_print(DLOG_INFO,"HttpRequest"," function enter  %d", curl_err);
	FILE *fd=NULL;
	fd = fopen(path, "rb");
	  if(!fd)
	  {
		  dlog_print(DLOG_INFO,"HttpRequest","Curl Failed bcoz of file:  %s", path);
	  	  return 1;
	  }

	  if(fstat(fileno(fd), &file_info) != 0)
		 dlog_print(DLOG_INFO,"HttpRequest","Curl Failed fstat:  %d", curl_err);

		 curl = curl_easy_init();
		 	  dlog_print(DLOG_INFO,"HttpRequest"," init function   %d", curl_err);

		 //Setting Header
		struct curl_slist *chunk = NULL;

    		chunk = curl_slist_append(chunk, "Device: E8:7F:6B:OE:CD:AF");

   		 /* set our custom set of headers */
   		 curl_easy_setopt(curl, CURLOPT_HTTPHEADER, chunk);


		 	 curl_easy_setopt(curl, CURLOPT_URL, "https://intfinal.herokuapp.com/uploader");
		 	  dlog_print(DLOG_INFO,"HttpRequest"," Url enter   %d", curl_err);

		 	 curl_err= curl_easy_setopt(curl, CURLOPT_UPLOAD, 1L);
	  dlog_print(DLOG_INFO,"HttpRequest"," upload function   %d", curl_err);


	  curl_err=curl_easy_setopt(curl, CURLOPT_READDATA, fd);
	  dlog_print(DLOG_INFO,"HttpRequest"," read data from file    %d", curl_err);




	  curl_err=curl_easy_setopt(curl, CURLOPT_INFILESIZE_LARGE,
	                       (curl_off_t)file_info.st_size);

	  dlog_print(DLOG_INFO,"HttpRequest"," infile size %d", curl_err);


	 curl_err=curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
	  curl_err = curl_easy_perform(curl);

	  if (curl_err != CURLE_OK){
	  		dlog_print(DLOG_INFO,"HttpRequest","Curl Failed:  %d", curl_err);
	  	}else{
	  		dlog_print(DLOG_INFO,"HttpRequest","Curl Success %d",curl_err);
	  		long response_code;
	  		    curl_easy_getinfo(curl, CURLINFO_SPEED_UPLOAD, &response_code);
	  		  dlog_print(DLOG_INFO,"HttpRequest","Curl response code %d",response_code);
			curl_easy_getinfo(curl, CURLINFO_TOTAL_TIME_T, &total_time);

	  	}
	  	curl_easy_cleanup(curl);

	  	fclose(fd);


	return 0;
}
